package demo;

public class A {
	
private int i;		//Declaration

public A(int j) {
	i=j;			//Initialization
}
public int getI() {
	return i;
}						//Utilization
public void setI(int i) {
	this.i=i;
}
}
